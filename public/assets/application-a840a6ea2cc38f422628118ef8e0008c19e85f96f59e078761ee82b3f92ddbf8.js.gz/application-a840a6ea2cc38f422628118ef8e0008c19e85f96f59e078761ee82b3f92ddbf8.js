// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"
import "trix"
import "@rails/actiontext"

//https://www.youtube.com/watch?v=ZD7r75O46zM
import "swiper/css/bundle"

console.log('Hello World from application.js');
